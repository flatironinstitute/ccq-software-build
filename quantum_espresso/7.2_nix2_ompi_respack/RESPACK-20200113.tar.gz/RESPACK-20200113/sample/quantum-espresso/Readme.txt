# Examples: Al, La2CuO4, Si, and SrVO3. 

**.scf.in   : Input for pw.x (scf calculation)   
**.band.in  : Input for pw.x (band calculation) 
**.bands.in : Input for bands.x
input.in    : Input for RESPACK

Acknowledgement: Pseudopotential files are taken from http://www.quantum-simulation.org/potentials/sg15_oncv/  
