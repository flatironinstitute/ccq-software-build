# Examples: Al, La2CuO4, Si, SrVO3, TiO2. 

**.cg                  : Input for cgmrpt (xTAPP scf calculation)   
**.vb                  : Input for vbpef (xTAPP band dispersion calculation) 
ps-** and ps-**.ichr   : Norm-conserving pseudopotential
input.in               : Input for RESPACK
wsh.mpirun.torque-impi : Job-script example for torque (intel MPI)
wsh.mpirun.torque-ompi : Job-script example for torque (open MPI)
**.vesta               : geometry file for vesta  
