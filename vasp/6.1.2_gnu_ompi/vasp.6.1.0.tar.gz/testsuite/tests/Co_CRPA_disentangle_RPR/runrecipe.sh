#!/bin/bash
  # obtain test name 
  tmp=$( dirname `readlink -f $0 ` )
  JOB=`basename $tmp`
  #
  # set category 
  #
  CATEGORY="LREAL CRPA NCORE1 VASP6 WAN90"
  # 
  # check if test is performed, maybe early return
  # 
  ShallIDoTest $JOB
  if [ $DoTest = N ] ; then
     return 0 
  fi 
  # 
  # actual recipe description 
  # 
  cd $WORK
  cd $JOB
  echoxr CASE: $JOB
  run_recipe $JOB run_vasp
  install_ref
  check_CRPA $JOB
  check_energy_OUTCAR $JOB
  echox
