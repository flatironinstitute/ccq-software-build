#!/bin/bash
  # obtain test name 
  tmp=$( dirname `readlink -f $0 ` )
  JOB=`basename $tmp`
  #
  # set category 
  #
  CATEGORY="NOCUDA NCORE1 FAST"
  # 
  # check if test is performed, maybe early return
  # 
  ShallIDoTest $JOB
  if [ $DoTest = N ] ; then
     return 0 
  fi 
  # 
  # actual recipe description 
  # 
  cd $WORK/$JOB
  echoxr CASE: $JOB
  run_recipe $JOB run_vasp
  install_ref
  check_frequ $JOB
  check_energy $JOB
  check_forces $JOB
  check_stress $JOB
  echox
