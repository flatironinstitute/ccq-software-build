#!/bin/bash
  # obtain test name 
  tmp=$( dirname `readlink -f $0 ` )
  JOB=`basename $tmp`
  #
  # set category 
  #
  CATEGORY="NOCUDA LTMP2 VASP6 NCORE1"
  # 
  # check if test is performed, maybe early return
  # 
  ShallIDoTest $JOB
  if [ $DoTest = N ] ; then
     return 0 
  fi 
  # 
  # actual recipe description 
  # 
  cd $WORK
  cd $JOB
  echoxr CASE: $JOB
  run_recipe $JOB run_vasp
  install_ref
  check_LTMP2_energy $JOB
  echox
