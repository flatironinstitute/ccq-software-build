#!/bin/bash
  # obtain test name 
  tmp=$( dirname `readlink -f $0 ` )
  JOB=`basename $tmp`
  #
  # set category 
  #
  CATEGORY="NOCUDA VASP46"
  # 
  # check if test is performed, maybe early return
  # 
  if [ -f $WORK/NaCl_field_2/EXECUTED ] ; then 
     rm EXECUTED 
  fi 
  ShallIDoTest $JOB
  if [ $DoTest = N ] ; then
     return 0 
  fi 
  # 
  # actual recipe description 
  # 
  cd $WORK/$JOB
  echoxr CASE: $JOB
  run_recipe $JOB run_vasp
  install_ref
  check_dipole $JOB
  check_energy $JOB
  check_forces $JOB
  check_stress $JOB
  echox

  touch EXECUTED 

  if [ -f $WORK/NaCl_field_1/EXECUTED ] &&\
     [ -f $WORK/NaCl_field_2/EXECUTED ] ; then
     dipol2=`grep "dipolmoment" $WORK/NaCl_field_1/OUTCAR | tail -1 | awk '{ print $4 }'`
     dipol1=`grep "dipolmoment" $WORK/NaCl_field_2/OUTCAR | tail -1 | awk '{ print $4 }'`
     energy1=`grep "free  energy" $WORK/NaCl_field_1/OUTCAR | tail -1 | awk '{ print $5 }'`
     energy2=`grep "free  energy" $WORK/NaCl_field_2/OUTCAR | tail -1 | awk '{ print $5 }'`
     e1=`echo \($dipol1 +1* $dipol2\)/2*0.2 | bc -l`
     e2=`echo $energy1 -1* $energy2 | bc -l`
     echox energy differences between both calculations: $e2
     echox predicted energy difference using NaCl dipole moment: $e1
     echox 
  fi 
