#!/bin/bash
  # obtain test name 
  tmp=$( dirname `readlink -f $0 ` )
  JOB=`basename $tmp`
  #
  # set category 
  #
  CATEGORY="LREAL NCL SOC FAST"
  # 
  # check if test is performed, maybe early return
  # 
  ShallIDoTest $JOB
  if [ $DoTest = N ] ; then
     return 0 
  fi 
  # 
  # actual recipe description 
  # 
  cd $WORK/$JOB
  echoxr CASE: $JOB
  run_recipe $JOB run_vasp_nc
  install_ref
  e1=`get_eigenvalue 4`
  e2=`get_eigenvalue 5`
  so_split=`echo $e2 - $e1 | bc -l`
  echox "spin-orbit splitting in the p shell is" $so_split
  check_energy $JOB
  check_forces $JOB
  check_stress $JOB
  echox
